package me.matteogiovagnotti.springlamiapizzeria;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringlamiapizzeriaApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringlamiapizzeriaApplication.class, args);
	}

}
